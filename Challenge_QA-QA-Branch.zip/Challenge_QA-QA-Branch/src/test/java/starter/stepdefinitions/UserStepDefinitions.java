
package starter.stepdefinitions;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import starter.*;
import org.openqa.selenium.WebDriver;

public class UserStepDefinitions {
    private Actor susan = Actor.named("Susan");
    private WebDriver driver;

    @Given("the user is on the DemoBlaze home page")
    public void theUserIsOnTheDemoBlazeHomePage() {
        System.setProperty("webdriver.chrome.driver", "src/test/resources/webdriver/mac/chromedriver");

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--no-sandbox");
        options.addArguments("--remote-allow-origins=*");

        driver = new ChromeDriver(options);
        susan.whoCan(BrowseTheWeb.with(driver)).wasAbleTo(OpenTheHomePage.on());
    }


    @When("the user adds two products to the cart")
    public void theUserAddsTwoProductsToTheCart() {
        susan.attemptsTo(AddProductsToCart.withNumber(1));
        susan.attemptsTo(OpenTheHomePage.on());
        susan.attemptsTo(AddProductsToCart.withNumber(2));
    }
    @When("proceeds to the cart page")
    public void proceedsToTheCartPage() {
        susan.whoCan(BrowseTheWeb.with(driver)).wasAbleTo(OpenTheCartPage.on());
    }

    @When("click to placeOrder button")
    public void clickPlaceOrderButton() {
        susan.attemptsTo(ClickPlaceOrder.now());
    }

    @When("completes the order with details")
    public void completesTheOrderWithDetails() {
        susan.attemptsTo(CompleteOrderWithDetails.now());
    }

    @Then("the user should see a successful purchase message")
    public void theUserShouldSeeASuccessfulPurchaseMessage() {
        susan.attemptsTo(VerifySuccessfulPurchaseMessage.withMessage("Thank you for your purchase!"));
    }
    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
