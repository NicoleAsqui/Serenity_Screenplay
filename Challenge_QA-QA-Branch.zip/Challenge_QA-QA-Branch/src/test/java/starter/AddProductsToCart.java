package starter;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import org.openqa.selenium.By;

import static net.serenitybdd.screenplay.Tasks.instrumented;
public class AddProductsToCart implements Task {

    private int productNumber;

    public AddProductsToCart(int productNumber) {
        this.productNumber = productNumber;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(By.cssSelector("#tbodyid > div:nth-child(" + productNumber + ") > div > a")),
                Click.on(By.cssSelector("#tbodyid > div.row > div > a"))
        );
    }

    public static AddProductsToCart withNumber(int productNumber) {
        return instrumented(AddProductsToCart.class, productNumber);
    }
}
