package starter;
import net.serenitybdd.screenplay.targets.Target;

public class YourPageElement {

    public static Target PRODUCT_1 = Target.the("Product 1").locatedBy("#product1"); // Reemplaza con los selectores correctos
    public static Target PRODUCT_2 = Target.the("Product 2").locatedBy("#product2"); // Reemplaza con los selectores correctos
    public static Target CART_BUTTON = Target.the("Cart Button").locatedBy("#cartButton"); // Reemplaza con los selectores correctos
    public static Target PURCHASE_BUTTON = Target.the("Purchase Button").locatedBy("#purchaseButton"); // Reemplaza con los selectores correctos
    public static Target SUCCESSFUL_PURCHASE_MESSAGE = Target.the("Successful Purchase Message")
            .locatedBy("#orderModal > div > div"); // Reemplaza con el selector correcto
}
